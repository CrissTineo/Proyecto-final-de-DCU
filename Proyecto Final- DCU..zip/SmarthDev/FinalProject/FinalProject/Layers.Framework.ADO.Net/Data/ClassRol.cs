﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Layers.Framework.ADO.Net.Data
{
	public class ClassRol
	{
		public int IdRolUserEntidad { get; set; }
		public string NombreRol { get; set; }
	}
}
