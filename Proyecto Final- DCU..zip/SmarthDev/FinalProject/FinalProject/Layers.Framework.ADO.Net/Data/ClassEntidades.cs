﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Layers.Framework.ADO.Net.Data
{
	public class ClassEntidades
	{
		public int IdEntidad { get; set; }
		public string Descripcion { get; set; }
		public string DIRECCION { get; set; }
		public string Localidad { get; set; }
		public string TipoEntidad { get; set; }
		public int? IdTipoDocumento { get; set; }
		public decimal NumeroDocumento { get; set; }
		public string Telefonos { get; set; }
		public string URLPAaginaWeb { get; set; }
		public string URLFACEBOOK { get; set; }
		public string URLINSTAGRAM { get; set; }
		public string URLTWITTER { get; set; }
		public string URLTIKTOK { get; set; }
		public int IdGrupoEntidad { get; set; }
		public int IdTipoEntidad { get; set; }
		public decimal LimiteCredito { get; set; }
		public string UserNameEntidad { get; set; }
		public string PassworEntidad { get; set; }
		public int? IdRolUserEntidad { get; set; }
		public string Comentario { get; set; }
		public int? IdStatues { get; set; }
		public bool NoEliminable { get; set; }
		public DateTime? FechaRegistro { get; set; }
	}
}
