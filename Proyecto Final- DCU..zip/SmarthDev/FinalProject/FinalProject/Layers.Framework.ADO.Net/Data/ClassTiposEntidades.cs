﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Layers.Framework.ADO.Net.Data
{
	public class ClassTiposEntidades
	{
		public int IdTipoEntidad { get; set; }
		public string Descripcion { get; set; }
		public int IdGrupoEntidad { get; set; }
		public string Comentario { get; set; }
		public string Statues { get; set; }
		public bool NoEliminable { get; set; }
		public DateTime? FechaRegistro { get; set; }
	}
}
