﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class TipoEntidad : Form
    {
        public TipoEntidad()
        {
            InitializeComponent();
        }

        private void buttonCrear_Click(object sender, EventArgs e)
        {
            FormMantTipoEntidad mantTipoEntidad = new FormMantTipoEntidad();
            mantTipoEntidad.Show();
        }

        private void buttonEditar_Click(object sender, EventArgs e)
        {
            FormMantTipoEntidad mantTipoEntidad = new FormMantTipoEntidad();
            mantTipoEntidad.Show();
        }
    }
}
